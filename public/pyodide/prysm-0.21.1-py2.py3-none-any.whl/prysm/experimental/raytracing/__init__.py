"""Sequential Ray Tracing."""
